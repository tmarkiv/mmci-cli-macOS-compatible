function funeval(~, ~, value)
    global bp;
    bp = value;
    close(gcbf);           
end
