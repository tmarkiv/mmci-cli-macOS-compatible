# mmci-cli

Octave/Matlab code for the macroeconomic comparison using the macroeconomic model database (MMB)
