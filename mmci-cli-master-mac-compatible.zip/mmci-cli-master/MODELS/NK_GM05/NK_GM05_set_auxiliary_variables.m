function y = NK_GM05_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(20)=y(17);
y(21)=y(17);
y(22)=y(17);
y(23)=y(18);
y(24)=y(18);
y(25)=y(18);
y(26)=y(19);
y(27)=y(19);
y(28)=y(19);
y(29)=y(8);
y(30)=y(8);
y(31)=y(19);
y(32)=y(19);
y(33)=y(19);
y(34)=y(18);
y(35)=y(18);
y(36)=y(18);
y(37)=y(15);
y(38)=y(15);
y(39)=y(15);
y(40)=y(17);
y(41)=y(17);
y(42)=y(17);
