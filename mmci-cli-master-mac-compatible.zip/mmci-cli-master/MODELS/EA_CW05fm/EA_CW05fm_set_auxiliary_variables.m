function y = EA_CW05fm_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(37)=y(34);
y(38)=y(34);
y(39)=y(34);
y(40)=y(35);
y(41)=y(35);
y(42)=y(35);
y(43)=y(36);
y(44)=y(36);
y(45)=y(36);
y(46)=y(36);
y(47)=y(36);
y(48)=y(36);
y(49)=y(35);
y(50)=y(35);
y(51)=y(35);
y(52)=y(32);
y(53)=y(32);
y(54)=y(32);
y(55)=y(34);
y(56)=y(34);
y(57)=y(34);
