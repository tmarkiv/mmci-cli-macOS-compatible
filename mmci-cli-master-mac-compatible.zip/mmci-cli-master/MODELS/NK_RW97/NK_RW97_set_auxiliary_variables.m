function y = NK_RW97_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(16)=y(12);
y(17)=y(12);
y(18)=y(12);
y(19)=y(13);
y(20)=y(13);
y(21)=y(13);
y(22)=y(14);
y(23)=y(14);
y(24)=y(14);
y(25)=y(1);
y(26)=y(1);
y(27)=y(14);
y(28)=y(14);
y(29)=y(14);
y(30)=y(13);
y(31)=y(13);
y(32)=y(13);
y(33)=y(10);
y(34)=y(10);
y(35)=y(10);
y(36)=y(12);
y(37)=y(12);
y(38)=y(12);
