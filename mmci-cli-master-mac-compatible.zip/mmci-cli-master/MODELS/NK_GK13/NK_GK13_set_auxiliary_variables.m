function y = NK_GK13_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(132)=y(128);
y(133)=y(132);
y(134)=y(133);
y(135)=y(129);
y(136)=y(135);
y(137)=y(136);
y(138)=y(130);
y(139)=y(138);
y(140)=y(139);
y(141)=y(57);
y(142)=y(141);
y(143)=y(130);
y(144)=y(143);
y(145)=y(144);
y(146)=y(129);
y(147)=y(146);
y(148)=y(147);
y(149)=y(126);
y(150)=y(149);
y(151)=y(150);
y(152)=y(128);
y(153)=y(152);
y(154)=y(153);
y(155)=y(61);
y(156)=y(62);
y(157)=y(120);
y(158)=y(121);
