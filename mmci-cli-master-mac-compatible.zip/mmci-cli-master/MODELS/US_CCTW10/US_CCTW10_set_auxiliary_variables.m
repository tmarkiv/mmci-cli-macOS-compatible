function y = US_CCTW10_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(65)=y(61);
y(66)=y(61);
y(67)=y(61);
y(68)=y(62);
y(69)=y(62);
y(70)=y(62);
y(71)=y(63);
y(72)=y(63);
y(73)=y(63);
y(74)=y(63);
y(75)=y(63);
y(76)=y(63);
y(77)=y(62);
y(78)=y(62);
y(79)=y(62);
y(80)=y(59);
y(81)=y(59);
y(82)=y(59);
y(83)=y(61);
y(84)=y(61);
y(85)=y(61);
