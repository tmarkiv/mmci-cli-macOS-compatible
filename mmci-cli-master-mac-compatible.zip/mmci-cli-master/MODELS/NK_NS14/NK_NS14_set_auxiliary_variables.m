function y = NK_NS14_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(54)=y(50);
y(55)=y(54);
y(56)=y(55);
y(57)=y(53);
y(58)=y(57);
y(59)=y(58);
y(60)=y(51);
y(61)=y(60);
y(62)=y(61);
y(63)=y(4);
y(64)=y(63);
y(65)=y(5);
y(66)=y(65);
y(67)=y(51);
y(68)=y(67);
y(69)=y(68);
y(70)=y(53);
y(71)=y(70);
y(72)=y(71);
y(73)=y(48);
y(74)=y(73);
y(75)=y(74);
y(76)=y(50);
y(77)=y(76);
y(78)=y(77);
