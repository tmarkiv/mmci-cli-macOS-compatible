function y = EAUS_NAWMctww_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(244)=y(240);
y(245)=y(240);
y(246)=y(240);
y(247)=y(241);
y(248)=y(241);
y(249)=y(241);
y(250)=y(242);
y(251)=y(242);
y(252)=y(242);
y(253)=y(242);
y(254)=y(242);
y(255)=y(242);
y(256)=y(241);
y(257)=y(241);
y(258)=y(241);
y(259)=y(238);
y(260)=y(238);
y(261)=y(238);
y(262)=y(240);
y(263)=y(240);
y(264)=y(240);
y(265)=y(52);
y(266)=y(64);
y(267)=y(64);
y(268)=y(167);
y(269)=y(179);
y(270)=y(179);
