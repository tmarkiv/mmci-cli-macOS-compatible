function y = US_OR03_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(9)=y(6);
y(10)=y(6);
y(11)=y(6);
y(12)=y(7);
y(13)=y(7);
y(14)=y(7);
y(15)=y(8);
y(16)=y(8);
y(17)=y(8);
y(18)=y(2);
y(19)=y(2);
y(20)=y(8);
y(21)=y(8);
y(22)=y(8);
y(23)=y(7);
y(24)=y(7);
y(25)=y(7);
y(26)=y(4);
y(27)=y(4);
y(28)=y(4);
y(29)=y(6);
y(30)=y(6);
y(31)=y(6);
y(32)=y(2);
y(33)=y(1);
y(34)=y(1);
y(35)=y(1);
y(36)=y(3);
y(37)=y(3);
y(38)=y(3);
