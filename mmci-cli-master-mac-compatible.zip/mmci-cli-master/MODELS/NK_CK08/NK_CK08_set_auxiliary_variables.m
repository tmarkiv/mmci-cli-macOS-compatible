function y = NK_CK08_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(33)=y(29);
y(34)=y(29);
y(35)=y(29);
y(36)=y(30);
y(37)=y(30);
y(38)=y(30);
y(39)=y(31);
y(40)=y(31);
y(41)=y(31);
y(42)=y(31);
y(43)=y(31);
y(44)=y(31);
y(45)=y(30);
y(46)=y(30);
y(47)=y(30);
y(48)=y(27);
y(49)=y(27);
y(50)=y(27);
y(51)=y(29);
y(52)=y(29);
y(53)=y(29);
y(54)=y(11);
y(55)=y(11);
