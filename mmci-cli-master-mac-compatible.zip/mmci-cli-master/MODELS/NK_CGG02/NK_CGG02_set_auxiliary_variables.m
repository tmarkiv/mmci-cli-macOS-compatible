function y = NK_CGG02_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(22)=y(19);
y(23)=y(19);
y(24)=y(19);
y(25)=y(20);
y(26)=y(20);
y(27)=y(20);
y(28)=y(21);
y(29)=y(21);
y(30)=y(21);
y(31)=y(12);
y(32)=y(12);
y(33)=y(12);
y(34)=y(9);
y(35)=y(9);
y(36)=y(9);
y(37)=y(4);
y(38)=y(4);
y(39)=y(21);
y(40)=y(21);
y(41)=y(21);
y(42)=y(20);
y(43)=y(20);
y(44)=y(20);
y(45)=y(17);
y(46)=y(17);
y(47)=y(17);
y(48)=y(19);
y(49)=y(19);
y(50)=y(19);
y(51)=y(9);
y(52)=y(9);
y(53)=y(9);
y(54)=y(13);
y(55)=y(13);
y(56)=y(13);
y(57)=y(12);
y(58)=y(12);
y(59)=y(12);
