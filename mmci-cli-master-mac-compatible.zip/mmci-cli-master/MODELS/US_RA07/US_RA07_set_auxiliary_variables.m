function y = US_RA07_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(34)=y(30);
y(35)=y(30);
y(36)=y(30);
y(37)=y(32);
y(38)=y(32);
y(39)=y(32);
y(40)=y(31);
y(41)=y(31);
y(42)=y(31);
y(43)=y(1);
y(44)=y(1);
y(45)=y(31);
y(46)=y(31);
y(47)=y(31);
y(48)=y(32);
y(49)=y(32);
y(50)=y(32);
y(51)=y(28);
y(52)=y(28);
y(53)=y(28);
y(54)=y(30);
y(55)=y(30);
y(56)=y(30);
