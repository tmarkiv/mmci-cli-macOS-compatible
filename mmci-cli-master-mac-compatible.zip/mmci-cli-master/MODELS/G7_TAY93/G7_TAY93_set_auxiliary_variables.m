function y = G7_TAY93_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(357)=y(353);
y(358)=y(353);
y(359)=y(353);
y(360)=y(354);
y(361)=y(354);
y(362)=y(354);
y(363)=y(355);
y(364)=y(355);
y(365)=y(355);
y(366)=y(355);
y(367)=y(355);
y(368)=y(355);
y(369)=y(354);
y(370)=y(354);
y(371)=y(354);
y(372)=y(351);
y(373)=y(351);
y(374)=y(351);
y(375)=y(353);
y(376)=y(353);
y(377)=y(353);
