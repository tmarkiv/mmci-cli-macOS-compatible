function y = US_FRB08mx_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(446)=y(442);
y(447)=y(442);
y(448)=y(442);
y(449)=y(443);
y(450)=y(443);
y(451)=y(443);
y(452)=y(444);
y(453)=y(444);
y(454)=y(444);
y(455)=y(3);
y(456)=y(3);
y(457)=y(444);
y(458)=y(444);
y(459)=y(444);
y(460)=y(443);
y(461)=y(443);
y(462)=y(443);
y(463)=y(440);
y(464)=y(440);
y(465)=y(440);
y(466)=y(442);
y(467)=y(442);
y(468)=y(442);
y(469)=y(314);
y(470)=y(316);
y(471)=y(318);
y(472)=y(320);
y(473)=y(322);
y(474)=y(324);
