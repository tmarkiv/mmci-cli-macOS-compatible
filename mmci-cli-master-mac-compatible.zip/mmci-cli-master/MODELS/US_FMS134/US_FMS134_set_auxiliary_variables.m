function y = US_FMS134_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(54)=y(50);
y(55)=y(54);
y(56)=y(55);
y(57)=y(51);
y(58)=y(57);
y(59)=y(58);
y(60)=y(52);
y(61)=y(60);
y(62)=y(61);
y(63)=y(39);
y(64)=y(16);
y(65)=y(52);
y(66)=y(65);
y(67)=y(66);
y(68)=y(51);
y(69)=y(68);
y(70)=y(69);
y(71)=y(48);
y(72)=y(71);
y(73)=y(72);
y(74)=y(50);
y(75)=y(74);
y(76)=y(75);
y(77)=y(13);
y(78)=y(77);
