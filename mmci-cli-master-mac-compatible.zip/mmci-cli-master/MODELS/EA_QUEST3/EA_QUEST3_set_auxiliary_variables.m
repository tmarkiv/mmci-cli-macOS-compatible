function y = EA_QUEST3_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(111)=y(108);
y(112)=y(108);
y(113)=y(108);
y(114)=y(109);
y(115)=y(109);
y(116)=y(109);
y(117)=y(108);
y(118)=y(108);
y(119)=y(109);
y(120)=y(109);
y(121)=y(109);
y(122)=y(106);
y(123)=y(106);
y(124)=y(106);
y(125)=y(108);
y(126)=y(96);
y(127)=y(96);
y(128)=y(96);
