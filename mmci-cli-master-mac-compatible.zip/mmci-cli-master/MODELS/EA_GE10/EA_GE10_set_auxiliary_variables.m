function y = EA_GE10_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(40)=y(36);
y(41)=y(36);
y(42)=y(36);
y(43)=y(38);
y(44)=y(38);
y(45)=y(38);
y(46)=y(37);
y(47)=y(37);
y(48)=y(37);
y(49)=y(10);
y(50)=y(10);
y(51)=y(37);
y(52)=y(37);
y(53)=y(37);
y(54)=y(38);
y(55)=y(38);
y(56)=y(38);
y(57)=y(34);
y(58)=y(34);
y(59)=y(34);
y(60)=y(36);
y(61)=y(36);
y(62)=y(36);
y(63)=y(5);
