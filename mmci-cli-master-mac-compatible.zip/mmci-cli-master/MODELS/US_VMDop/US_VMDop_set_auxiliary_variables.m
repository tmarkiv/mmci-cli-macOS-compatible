function y = US_VMDop_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(86)=y(83);
y(87)=y(83);
y(88)=y(83);
y(89)=y(84);
y(90)=y(84);
y(91)=y(84);
y(92)=y(85);
y(93)=y(85);
y(94)=y(85);
y(95)=y(83);
y(96)=y(83);
y(97)=y(85);
y(98)=y(85);
y(99)=y(85);
y(100)=y(84);
y(101)=y(84);
y(102)=y(84);
y(103)=y(81);
y(104)=y(81);
y(105)=y(81);
y(106)=y(83);
