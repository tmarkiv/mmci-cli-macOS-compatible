function y = HK_FPP11_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(19)=y(16);
y(20)=y(16);
y(21)=y(16);
y(22)=y(17);
y(23)=y(17);
y(24)=y(17);
y(25)=y(18);
y(26)=y(18);
y(27)=y(18);
y(28)=y(8);
y(29)=y(8);
y(30)=y(18);
y(31)=y(18);
y(32)=y(18);
y(33)=y(17);
y(34)=y(17);
y(35)=y(17);
y(36)=y(14);
y(37)=y(14);
y(38)=y(14);
y(39)=y(16);
y(40)=y(16);
y(41)=y(16);
