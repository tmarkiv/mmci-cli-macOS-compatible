function y = CL_MS07_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(131)=y(127);
y(132)=y(127);
y(133)=y(127);
y(134)=y(129);
y(135)=y(129);
y(136)=y(129);
y(137)=y(128);
y(138)=y(128);
y(139)=y(128);
y(140)=y(32);
y(141)=y(32);
y(142)=y(128);
y(143)=y(128);
y(144)=y(128);
y(145)=y(129);
y(146)=y(129);
y(147)=y(129);
y(148)=y(125);
y(149)=y(125);
y(150)=y(125);
y(151)=y(127);
y(152)=y(127);
y(153)=y(127);
