function y = NK_CGG99_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(8)=y(6);
y(9)=y(6);
y(10)=y(6);
y(11)=y(7);
y(12)=y(7);
y(13)=y(7);
y(14)=y(3);
y(15)=y(3);
y(16)=y(7);
y(17)=y(7);
y(18)=y(7);
y(19)=y(4);
y(20)=y(4);
y(21)=y(4);
y(22)=y(6);
y(23)=y(6);
y(24)=y(6);
