function y = EA_SR07_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(104)=y(100);
y(105)=y(100);
y(106)=y(100);
y(107)=y(101);
y(108)=y(101);
y(109)=y(101);
y(110)=y(102);
y(111)=y(102);
y(112)=y(102);
y(113)=y(48);
y(114)=y(48);
y(115)=y(102);
y(116)=y(102);
y(117)=y(102);
y(118)=y(101);
y(119)=y(101);
y(120)=y(101);
y(121)=y(98);
y(122)=y(98);
y(123)=y(98);
y(124)=y(100);
y(125)=y(100);
y(126)=y(100);
y(127)=y(28);
y(128)=y(29);
y(129)=y(31);
y(130)=y(24);
y(131)=y(25);
y(132)=y(26);
y(133)=y(24);
y(134)=y(25);
y(135)=y(26);
y(136)=y(24);
y(137)=y(25);
y(138)=y(26);
y(139)=y(94);
y(140)=y(95);
y(141)=y(96);
y(142)=y(94);
y(143)=y(95);
y(144)=y(96);
y(145)=y(94);
y(146)=y(95);
y(147)=y(96);
