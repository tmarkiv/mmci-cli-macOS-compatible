function y = US_FRB08_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(370)=y(366);
y(371)=y(366);
y(372)=y(366);
y(373)=y(367);
y(374)=y(367);
y(375)=y(367);
y(376)=y(368);
y(377)=y(368);
y(378)=y(368);
y(379)=y(3);
y(380)=y(3);
y(381)=y(368);
y(382)=y(368);
y(383)=y(368);
y(384)=y(367);
y(385)=y(367);
y(386)=y(367);
y(387)=y(364);
y(388)=y(364);
y(389)=y(364);
y(390)=y(366);
y(391)=y(366);
y(392)=y(366);
y(393)=y(298);
y(394)=y(300);
y(395)=y(302);
y(396)=y(304);
y(397)=y(306);
y(398)=y(308);
