function y = EA_SW03_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(66)=y(62);
y(67)=y(62);
y(68)=y(62);
y(69)=y(63);
y(70)=y(63);
y(71)=y(63);
y(72)=y(64);
y(73)=y(64);
y(74)=y(64);
y(75)=y(64);
y(76)=y(64);
y(77)=y(64);
y(78)=y(63);
y(79)=y(63);
y(80)=y(63);
y(81)=y(60);
y(82)=y(60);
y(83)=y(60);
y(84)=y(62);
y(85)=y(62);
y(86)=y(62);
