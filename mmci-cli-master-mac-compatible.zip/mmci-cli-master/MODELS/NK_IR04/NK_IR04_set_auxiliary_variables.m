function y = NK_IR04_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(13)=y(10);
y(14)=y(10);
y(15)=y(10);
y(16)=y(11);
y(17)=y(11);
y(18)=y(11);
y(19)=y(12);
y(20)=y(12);
y(21)=y(12);
y(22)=y(3);
y(23)=y(3);
y(24)=y(12);
y(25)=y(12);
y(26)=y(12);
y(27)=y(11);
y(28)=y(11);
y(29)=y(11);
y(30)=y(8);
y(31)=y(8);
y(32)=y(8);
y(33)=y(10);
y(34)=y(10);
y(35)=y(10);
