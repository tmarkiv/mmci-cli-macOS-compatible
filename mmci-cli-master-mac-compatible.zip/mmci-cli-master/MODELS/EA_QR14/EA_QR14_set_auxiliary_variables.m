function y = EA_QR14_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(211)=y(208);
y(212)=y(208);
y(213)=y(208);
y(214)=y(210);
y(215)=y(210);
y(216)=y(210);
y(217)=y(209);
y(218)=y(209);
y(219)=y(209);
y(220)=y(166);
y(221)=y(167);
y(222)=y(137);
y(223)=y(148);
y(224)=y(23);
y(225)=y(47);
y(226)=y(21);
y(227)=y(45);
y(228)=y(72);
y(229)=y(72);
y(230)=y(209);
y(231)=y(209);
y(232)=y(209);
y(233)=y(210);
y(234)=y(210);
y(235)=y(210);
y(236)=y(206);
y(237)=y(206);
y(238)=y(206);
y(239)=y(208);
y(240)=y(208);
y(241)=y(208);
y(242)=y(168);
y(243)=y(169);
y(244)=y(138);
y(245)=y(149);
y(246)=y(24);
y(247)=y(48);
y(248)=y(22);
y(249)=y(46);
