function y = US_IAC05_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(36)=y(33);
y(37)=y(33);
y(38)=y(33);
y(39)=y(35);
y(40)=y(35);
y(41)=y(35);
y(42)=y(34);
y(43)=y(34);
y(44)=y(34);
y(45)=y(13);
y(46)=y(13);
y(47)=y(34);
y(48)=y(34);
y(49)=y(34);
y(50)=y(35);
y(51)=y(35);
y(52)=y(35);
y(53)=y(31);
y(54)=y(31);
y(55)=y(31);
y(56)=y(33);
y(57)=y(33);
y(58)=y(33);
