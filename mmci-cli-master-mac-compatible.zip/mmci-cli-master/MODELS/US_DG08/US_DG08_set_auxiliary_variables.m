function y = US_DG08_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(38)=y(34);
y(39)=y(34);
y(40)=y(34);
y(41)=y(35);
y(42)=y(35);
y(43)=y(35);
y(44)=y(36);
y(45)=y(36);
y(46)=y(36);
y(47)=y(6);
y(48)=y(6);
y(49)=y(36);
y(50)=y(36);
y(51)=y(36);
y(52)=y(35);
y(53)=y(35);
y(54)=y(35);
y(55)=y(32);
y(56)=y(32);
y(57)=y(32);
y(58)=y(34);
y(59)=y(34);
y(60)=y(34);
