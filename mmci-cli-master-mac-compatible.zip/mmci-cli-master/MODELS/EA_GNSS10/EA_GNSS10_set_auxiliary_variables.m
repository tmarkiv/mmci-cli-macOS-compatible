function y = EA_GNSS10_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(120)=y(117);
y(121)=y(117);
y(122)=y(117);
y(123)=y(118);
y(124)=y(118);
y(125)=y(118);
y(126)=y(119);
y(127)=y(119);
y(128)=y(119);
y(129)=y(35);
y(130)=y(35);
y(131)=y(119);
y(132)=y(119);
y(133)=y(119);
y(134)=y(118);
y(135)=y(118);
y(136)=y(118);
y(137)=y(115);
y(138)=y(115);
y(139)=y(115);
y(140)=y(117);
y(141)=y(117);
y(142)=y(117);
y(143)=y(30);
y(144)=y(32);
y(145)=y(31);
