function y = US_DNGS15_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(43)=y(39);
y(44)=y(43);
y(45)=y(44);
y(46)=y(40);
y(47)=y(46);
y(48)=y(47);
y(49)=y(41);
y(50)=y(49);
y(51)=y(50);
y(52)=y(3);
y(53)=y(52);
y(54)=y(41);
y(55)=y(54);
y(56)=y(55);
y(57)=y(40);
y(58)=y(57);
y(59)=y(58);
y(60)=y(37);
y(61)=y(60);
y(62)=y(61);
y(63)=y(39);
y(64)=y(63);
y(65)=y(64);
