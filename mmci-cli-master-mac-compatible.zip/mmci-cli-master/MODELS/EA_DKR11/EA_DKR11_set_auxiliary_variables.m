function y = EA_DKR11_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(376)=y(373);
y(377)=y(376);
y(378)=y(377);
y(379)=y(374);
y(380)=y(379);
y(381)=y(380);
y(382)=y(375);
y(383)=y(382);
y(384)=y(383);
y(385)=y(69);
y(386)=y(385);
y(387)=y(375);
y(388)=y(387);
y(389)=y(388);
y(390)=y(374);
y(391)=y(390);
y(392)=y(391);
y(393)=y(371);
y(394)=y(393);
y(395)=y(394);
y(396)=y(373);
y(397)=y(396);
y(398)=y(397);
