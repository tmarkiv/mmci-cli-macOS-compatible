function y = NK_RW06_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(8)=y(6);
y(9)=y(8);
y(10)=y(9);
y(11)=y(7);
y(12)=y(11);
y(13)=y(12);
y(14)=y(2);
y(15)=y(14);
y(16)=y(7);
y(17)=y(16);
y(18)=y(17);
y(19)=y(4);
y(20)=y(19);
y(21)=y(20);
y(22)=y(6);
y(23)=y(22);
y(24)=y(23);
