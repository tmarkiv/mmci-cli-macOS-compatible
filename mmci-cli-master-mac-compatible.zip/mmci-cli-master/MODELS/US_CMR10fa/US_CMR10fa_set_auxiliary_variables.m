function y = US_CMR10fa_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(57)=y(54);
y(58)=y(54);
y(59)=y(54);
y(60)=y(55);
y(61)=y(55);
y(62)=y(55);
y(63)=y(56);
y(64)=y(56);
y(65)=y(56);
y(66)=y(54);
y(67)=y(54);
y(68)=y(56);
y(69)=y(56);
y(70)=y(56);
y(71)=y(55);
y(72)=y(55);
y(73)=y(55);
y(74)=y(52);
y(75)=y(52);
y(76)=y(52);
y(77)=y(54);
