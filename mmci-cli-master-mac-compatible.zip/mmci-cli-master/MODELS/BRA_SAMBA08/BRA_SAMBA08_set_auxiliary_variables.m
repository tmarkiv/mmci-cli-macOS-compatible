function y = BRA_SAMBA08_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(49)=y(45);
y(50)=y(45);
y(51)=y(45);
y(52)=y(46);
y(53)=y(46);
y(54)=y(46);
y(55)=y(47);
y(56)=y(47);
y(57)=y(47);
y(58)=y(18);
y(59)=y(18);
y(60)=y(47);
y(61)=y(47);
y(62)=y(47);
y(63)=y(46);
y(64)=y(46);
y(65)=y(46);
y(66)=y(43);
y(67)=y(43);
y(68)=y(43);
y(69)=y(45);
y(70)=y(45);
y(71)=y(45);
