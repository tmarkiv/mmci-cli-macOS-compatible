function y = US_CMR10_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(79)=y(76);
y(80)=y(76);
y(81)=y(76);
y(82)=y(77);
y(83)=y(77);
y(84)=y(77);
y(85)=y(78);
y(86)=y(78);
y(87)=y(78);
y(88)=y(76);
y(89)=y(76);
y(90)=y(78);
y(91)=y(78);
y(92)=y(78);
y(93)=y(77);
y(94)=y(77);
y(95)=y(77);
y(96)=y(74);
y(97)=y(74);
y(98)=y(74);
y(99)=y(76);
y(100)=y(12);
y(101)=y(56);
