function y = US_CD08_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(40)=y(37);
y(41)=y(37);
y(42)=y(37);
y(43)=y(39);
y(44)=y(39);
y(45)=y(39);
y(46)=y(38);
y(47)=y(38);
y(48)=y(38);
y(49)=y(16);
y(50)=y(16);
y(51)=y(38);
y(52)=y(38);
y(53)=y(38);
y(54)=y(39);
y(55)=y(39);
y(56)=y(39);
y(57)=y(35);
y(58)=y(35);
y(59)=y(35);
y(60)=y(37);
y(61)=y(37);
y(62)=y(37);
