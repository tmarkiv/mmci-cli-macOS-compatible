function y = NK_BGUS10_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(22)=y(18);
y(23)=y(22);
y(24)=y(23);
y(25)=y(19);
y(26)=y(25);
y(27)=y(26);
y(28)=y(20);
y(29)=y(28);
y(30)=y(29);
y(31)=y(1);
y(32)=y(31);
y(33)=y(20);
y(34)=y(33);
y(35)=y(34);
y(36)=y(19);
y(37)=y(36);
y(38)=y(37);
y(39)=y(16);
y(40)=y(39);
y(41)=y(40);
y(42)=y(18);
y(43)=y(42);
y(44)=y(43);
