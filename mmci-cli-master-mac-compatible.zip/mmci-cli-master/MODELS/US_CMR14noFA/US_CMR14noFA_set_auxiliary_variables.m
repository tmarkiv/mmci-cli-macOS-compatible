function y = US_CMR14noFA_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(59)=y(55);
y(60)=y(55);
y(61)=y(55);
y(62)=y(56);
y(63)=y(56);
y(64)=y(56);
y(65)=y(57);
y(66)=y(57);
y(67)=y(57);
y(68)=y(55);
y(69)=y(55);
y(70)=y(57);
y(71)=y(57);
y(72)=y(57);
y(73)=y(56);
y(74)=y(56);
y(75)=y(56);
y(76)=y(53);
y(77)=y(53);
y(78)=y(53);
y(79)=y(55);
