function y = RBC_DTT11_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(31)=y(28);
y(32)=y(31);
y(33)=y(32);
y(34)=y(30);
y(35)=y(34);
y(36)=y(35);
y(37)=y(29);
y(38)=y(37);
y(39)=y(38);
y(40)=y(3);
y(41)=y(40);
y(42)=y(29);
y(43)=y(42);
y(44)=y(43);
y(45)=y(30);
y(46)=y(45);
y(47)=y(46);
y(48)=y(26);
y(49)=y(48);
y(50)=y(49);
y(51)=y(28);
y(52)=y(51);
y(53)=y(52);
