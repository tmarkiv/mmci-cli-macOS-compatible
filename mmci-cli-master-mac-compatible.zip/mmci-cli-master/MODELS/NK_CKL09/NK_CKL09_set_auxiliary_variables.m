function y = NK_CKL09_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(51)=y(47);
y(52)=y(47);
y(53)=y(47);
y(54)=y(48);
y(55)=y(48);
y(56)=y(48);
y(57)=y(49);
y(58)=y(49);
y(59)=y(49);
y(60)=y(49);
y(61)=y(49);
y(62)=y(49);
y(63)=y(48);
y(64)=y(48);
y(65)=y(48);
y(66)=y(45);
y(67)=y(45);
y(68)=y(45);
y(69)=y(47);
y(70)=y(47);
y(71)=y(47);
y(72)=y(11);
y(73)=y(11);
