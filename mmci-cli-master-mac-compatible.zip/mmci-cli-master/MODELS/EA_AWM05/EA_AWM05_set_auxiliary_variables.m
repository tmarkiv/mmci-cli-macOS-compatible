function y = EA_AWM05_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(197)=y(193);
y(198)=y(193);
y(199)=y(193);
y(200)=y(194);
y(201)=y(194);
y(202)=y(194);
y(203)=y(195);
y(204)=y(195);
y(205)=y(195);
y(206)=y(1);
y(207)=y(1);
y(208)=y(1);
y(209)=y(1);
y(210)=y(1);
y(211)=y(1);
y(212)=y(1);
y(213)=y(1);
y(214)=y(1);
y(215)=y(1);
y(216)=y(1);
y(217)=y(1);
y(218)=y(1);
y(219)=y(1);
y(220)=y(1);
y(221)=y(1);
y(222)=y(1);
y(223)=y(1);
y(224)=y(195);
y(225)=y(195);
y(226)=y(195);
y(227)=y(194);
y(228)=y(194);
y(229)=y(194);
y(230)=y(191);
y(231)=y(191);
y(232)=y(191);
y(233)=y(193);
y(234)=y(193);
y(235)=y(193);
y(236)=y(43);
