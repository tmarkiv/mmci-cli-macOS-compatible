function y = CA_BMZ12_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(69)=y(66);
y(70)=y(66);
y(71)=y(66);
y(72)=y(67);
y(73)=y(67);
y(74)=y(67);
y(75)=y(68);
y(76)=y(68);
y(77)=y(68);
y(78)=y(66);
y(79)=y(66);
y(80)=y(68);
y(81)=y(68);
y(82)=y(68);
y(83)=y(67);
y(84)=y(67);
y(85)=y(67);
y(86)=y(64);
y(87)=y(64);
y(88)=y(64);
y(89)=y(66);
