function y = NK_LWW03_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(11)=y(9);
y(12)=y(9);
y(13)=y(9);
y(14)=y(10);
y(15)=y(10);
y(16)=y(10);
y(17)=y(2);
y(18)=y(2);
y(19)=y(10);
y(20)=y(10);
y(21)=y(10);
y(22)=y(7);
y(23)=y(7);
y(24)=y(7);
y(25)=y(9);
y(26)=y(9);
y(27)=y(9);
