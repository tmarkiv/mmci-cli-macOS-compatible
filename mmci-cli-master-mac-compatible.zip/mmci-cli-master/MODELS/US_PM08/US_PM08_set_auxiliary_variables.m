function y = US_PM08_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(16)=y(13);
y(17)=y(13);
y(18)=y(13);
y(19)=y(14);
y(20)=y(14);
y(21)=y(14);
y(22)=y(15);
y(23)=y(15);
y(24)=y(15);
y(25)=y(5);
y(26)=y(5);
y(27)=y(5);
y(28)=y(15);
y(29)=y(15);
y(30)=y(15);
y(31)=y(14);
y(32)=y(14);
y(33)=y(14);
y(34)=y(11);
y(35)=y(11);
y(36)=y(11);
y(37)=y(13);
y(38)=y(13);
y(39)=y(13);
y(40)=y(4);
y(41)=y(4);
