function y = US_PM08fl_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(18)=y(15);
y(19)=y(15);
y(20)=y(15);
y(21)=y(16);
y(22)=y(16);
y(23)=y(16);
y(24)=y(17);
y(25)=y(17);
y(26)=y(17);
y(27)=y(5);
y(28)=y(5);
y(29)=y(5);
y(30)=y(17);
y(31)=y(17);
y(32)=y(17);
y(33)=y(16);
y(34)=y(16);
y(35)=y(16);
y(36)=y(13);
y(37)=y(13);
y(38)=y(13);
y(39)=y(15);
y(40)=y(15);
y(41)=y(15);
y(42)=y(11);
y(43)=y(11);
y(44)=y(11);
y(45)=y(11);
y(46)=y(11);
y(47)=y(11);
y(48)=y(11);
y(49)=y(11);
y(50)=y(4);
y(51)=y(4);
